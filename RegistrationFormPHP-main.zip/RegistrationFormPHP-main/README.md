# RegistrationFormPHP
 created a login and registration form using php
